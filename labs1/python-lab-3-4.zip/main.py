'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
import numpy as np
# Random matrix 2x3, uniform distribution [0, 1)
R = np.random.rand(2, 3)
print("Random Matrix 2x3 (Uniform Distribution):\n", R)
# Random matrix 2x3, normal distribution (mean=0, std=1)
N = np.random.randn(2, 3)
print("Random Matrix 2x3 (Normal Distribution):\n", N)