/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <stdio.h>
#define ROWS 3
#define COLS 3
int main() {
    int matrix[ROWS][COLS] = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
 int mat_2[COLS][ROWS];
 for (int i = 0; i < ROWS; i++) {
 for (int j = 0; j < COLS; j++) {
 mat_2[j][i] = matrix[i][j];
 }
 }
 printf("Transpose of the Matrix:\n");
 for (int i = 0; i < COLS; i++) {
 for (int j = 0; j < ROWS; j++) {
 printf("%d ", mat_2[i][j]);
 }
 printf("\n");
 }

}