'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
import numpy as np
Z = np.zeros((2, 4)) # Matrix of zeros 2x4
print("Matrix of zeros 2*4:\n", Z)
Z = np.zeros((4, 4)) # Matrix of zeros 4x4
Y = np.zeros(4)
print("Matrix of zeros 4*4 (Z):\n", Z)
print("Matrix of zeros 1*4 (Y):\n", Y)
U = np.ones((3, 2)) # Matrix of ones 3x2
print("Matrix of ones 3x2:\n", U)