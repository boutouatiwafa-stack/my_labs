/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
using namespace std;
int main()
{
  
 float num1= 12.5, num2= 34.7;
 float sum, difference, product, quotient;
         sum= num1+num2;
       difference= num1-num2;
       product= num1*num2;
       quotient= num1/num2;
    cout<<"sum:"<<sum<<endl;
    return 1;
}
