/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
#include <iostream>
using namespace std;
int main() {
char c1 = 'A';
char c2 = c1 + 3;
char c3 = 'Z' - 1;
cout << c1 << " " << c2 << " " << c3 << endl;
cout << "Code of c2 = " << (int)c2 << endl;
return 0;
}
