'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
# indexing in Python is zero-based
element = matrice[1, 2]
print("Element at (2, 3):", element)
# Matrix operations
matrice2 = matrice * 2 # Element-wise
multiplication
print("Matrix * 2:\n", matrice2)
matrice_add = matrice + matrice2 # Matrix addition
print("Matrix Addition:\n", matrice_add)
matrice_sub = matrice2 - matrice # Matrix
subtraction
print("Matrix Subtraction:\n", matrice_sub)
matrice_mult = np.dot(matrice, matrice) # dot
product
print("Matrix Multiplication (Dot Product):\n",matrice_mult)
matrice_sqrt = np.sqrt(matrice)
print("Element-wise Square Root:\n", matrice_sqrt)
matrice_transpose = np.transpose(matrice)
print("Transpose of the Matrix:\n", matrice_transpose)
# Sum of all elements
matrice_sum = np.sum(matrice)
print("Sum of All Elements:", matrice_sum)
matrice_det = np.linalg.det(matrice) # Determinant
of the matrix
print("Determinant of the Matrix:", matrice_det)