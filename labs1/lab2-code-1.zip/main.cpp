/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <iostream>
using namespace std;
int main() {
int a = 5;
int b = 2;
float result1 = a / b;
float result2 = (float) a / b;
char letter = 'A' + b * a;
bool check = (a * b % 2 == 0);
cout << "Result1 = " << result1 << endl;
cout << "Result2 = " << result2 << endl;
cout << "Letter = " << letter << endl;
cout << "Check = " << check << endl;
return 1;
}
